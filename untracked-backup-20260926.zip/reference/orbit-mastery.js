/* =====================================================================
   Orbit — "The Pathway to Clinical Mastery" constellation
   ---------------------------------------------------------------------
   Builds an orbital knowledge-graph illustration inside every
   [data-orbit] element: a glowing core, elliptical orbits that turn at
   different speeds, glass nodes with icons, curved connectors, drifting
   light travellers, floating annotation tags and four-point sparkles.

   Everything is SVG + CSS transforms — no per-frame JS, no canvas.
   Geometry lives in one 900x620 coordinate space; the HTML overlay is
   positioned with percentages of that same space, so the whole scene
   scales as one piece.

   Performance manners (same contract as the sky script):
   - Animations only run while the scene is on screen (IntersectionObserver)
     and the tab is visible (visibilitychange).
   - prefers-reduced-motion: everything freezes in a composed pose.
   - --u (unit scale) is set from the real width, so strokes, type and
     shadows scale together instead of drifting apart.

   Usage:  <div data-orbit></div>  + this file.
   Config: window.OrbitMastery.render(el, cfg)  — or edit CONFIG below.
   ===================================================================== */
(function () {
  'use strict';

  var SVGNS = 'http://www.w3.org/2000/svg';
  var XLINK = 'http://www.w3.org/1999/xlink';
  var VW = 900, VH = 620;                 // the one true coordinate space
  var REDUCED = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var uid = 0;

  /* ---------------------------------------------------------------- icons
     Stroke-only 24x24 glyphs. currentColor picks up the node accent. */
  var ICONS = {
    spine:
      '<path d="M12 3.2v17.6"/><path d="M8.6 6.2h6.8"/><path d="M8.1 9.7h7.8"/>' +
      '<path d="M8.1 13.2h7.8"/><path d="M8.6 16.7h6.8"/><path d="M9.8 20.2h4.4"/>',
    apple:
      '<path d="M12 8.6c-1.5-1.7-4.1-2-5.6-.3-1.7 1.8-1.2 5.2.4 7.6 1 1.5 2.4 3.2 4 3.8.8.3 1.6.3 2.4 0 1.6-.6 3-2.3 4-3.8 1.6-2.4 2.1-5.8.4-7.6-1.5-1.7-4.1-1.4-5.6.3Z"/>' +
      '<path d="M12 8.6V6.3c1.6-1.7 3.2-1.6 3.9-1.3.3.7.3 2.4-1.4 3.6"/>',
    book:
      '<path d="M4.2 5.6A2.4 2.4 0 0 1 6.6 3.2H19v14.2H6.6a2.4 2.4 0 0 0-2.4 2.4Z"/>' +
      '<path d="M4.2 19.8a2.4 2.4 0 0 1 2.4-2.4H19v3.4H6.6"/><path d="M9.2 7.6h6"/>',
    scales:
      '<path d="M12 3.4v17.2"/><path d="M7.2 20.6h9.6"/><path d="M4.6 6.8h14.8"/>' +
      '<path d="M4.6 6.8 2 13.4h5.2Z"/><path d="M19.4 6.8 16.8 13.4H22Z"/>',
    microscope:
      '<path d="M6.6 20.4h10.8"/><path d="M9.6 20.4a5.6 5.6 0 0 0 5.6-5.6"/>' +
      '<path d="M12.6 3.4 8.9 7.1l3.1 3.1 3.7-3.7a2.2 2.2 0 0 0-3.1-3.1Z"/>' +
      '<path d="M10.3 10.6 8.1 12.8"/><path d="M6.4 15.2h5.4"/>',
    pulse:
      '<path d="M2.8 12h4l2-5.4 3.4 11L15 12h6.2"/>'
  };

  /* --------------------------------------------------------------- config
     x / y are in the 900x620 space. Rename anything — the scene rebuilds
     from this object alone. */
  var CONFIG = {
    core: { x: 430, y: 300, label: 'Core Knowledge' },

    // Orbits are ellipses on the core. dur = seconds per full turn.
    rings: [
      { rx: 342, ry: 156, rot: -14, dur: 168, dir: 1,  flow: true,  travel: 22 },
      { rx: 268, ry: 238, rot:  28, dur: 214, dir: -1, flow: false, travel: 0  },
      { rx: 362, ry: 202, rot:  17, dur: 262, dir: 1,  flow: true,  travel: 30 },
      { rx: 188, ry: 174, rot: -37, dur: 126, dir: -1, flow: false, travel: 16 }
    ],

    nodes: [
      { id: 'physio',  x: 200, y: 352, label: 'Physiotherapy', icon: 'spine',      accent: '167,199,255', size: 74 },
      { id: 'nutri',   x: 640, y: 132, label: 'Nutrition',     icon: 'apple',      accent: '126,222,180', size: 62 },
      { id: 'research',x: 792, y: 196, label: 'Research',      icon: 'book',       accent: '255,164,132', size: 58 },
      { id: 'ethics',  x: 700, y: 448, label: 'Ethics',        icon: 'scales',     accent: '196,176,255', size: 58 },
      { id: 'evidence',x: 486, y: 526, label: 'Evidence',      icon: 'microscope', accent: '127,236,240', size: 62 }
    ],

    // Curved connectors. bend = how far the curve bows off the straight line.
    links: [
      { from: 'core', to: 'physio',   bend:  46 },
      { from: 'core', to: 'nutri',    bend: -40 },
      { from: 'core', to: 'research', bend:  34 },
      { from: 'core', to: 'ethics',   bend: -30 },
      { from: 'core', to: 'evidence', bend:  38 },
      { from: 'nutri',    to: 'research', bend: 26 },
      { from: 'research', to: 'ethics',   bend: 34 },
      { from: 'ethics',   to: 'evidence', bend: 30 },
      { from: 'evidence', to: 'physio',   bend: 34 }
    ],

    // Small unlabelled waypoints — the "in between" of a learning path.
    dots: [
      { x: 524, y: 96,  r: 9,  accent: '205,239,251' },
      { x: 352, y: 132, r: 6,  accent: '255,255,255' },
      { x: 596, y: 306, r: 5,  accent: '255,214,150' },
      { x: 300, y: 470, r: 6,  accent: '196,176,255' }
    ],

    tags: [
      { x: 296, y: 112, side: 'right', text: 'Physiotherapy Specialist Path' },
      { x: 852, y: 92,  side: 'left',  text: '90% Core Skills Complete' },
      { x: 852, y: 392, side: 'left',  text: 'Certification Pathway Active' },
      { x: 560, y: 576, side: 'right', text: 'Evidence-Based Practice' }
    ],

    sparkles: [
      { x: 330, y: 178, s: 30 }, { x: 262, y: 236, s: 16 },
      { x: 604, y: 252, s: 15 }, { x: 772, y: 336, s: 13 },
      { x: 858, y: 486, s: 26 }, { x: 424, y: 92,  s: 13 },
      { x: 470, y: 424, s: 11 }, { x: 152, y: 470, s: 18 }
    ]
  };

  /* ----------------------------------------------------------------- css */
  function styleText() {
    return [
      '.orb{position:relative;width:100%;max-width:900px;margin-inline:auto;',
        'aspect-ratio:900/620;--u:1;',
        '--orb-ink:#eef1ff;--orb-muted:rgba(226,232,255,.60);',
        '--orb-line:rgba(170,192,255,.34);--orb-core-a:#ffd79a;--orb-core-b:#ff8f3c;',
        'color:var(--orb-ink);-webkit-user-select:none;user-select:none;}',

      /* ---- rings ---- */
      '.orb__svg{position:absolute;inset:0;width:100%;height:100%;overflow:visible;}',
      '.orb__ring{fill:none;stroke:var(--orb-line);stroke-width:1;}',
      '.orb__ring--flow{stroke-dasharray:5 13;animation:orbFlow 9s linear infinite;}',
      '.orb__spin{transform-box:fill-box;transform-origin:center;',
        'animation:orbTurn var(--dur,180s) linear infinite;animation-direction:var(--dir,normal);}',
      '.orb__link{fill:none;stroke:rgba(178,196,255,.20);stroke-width:1;stroke-linecap:round;}',
      '.orb__travel{fill:#fff;filter:drop-shadow(0 0 5px rgba(160,220,255,.9));}',

      /* ---- core ---- */
      '.orb__core{position:absolute;width:0;height:0;}',
      '.orb__core>*{position:absolute;left:0;top:0;}',
      '.orb__halo{width:calc(340px*var(--u));height:calc(340px*var(--u));border-radius:50%;',
        'background:radial-gradient(circle,rgba(255,196,120,.30),rgba(255,150,70,.13) 38%,transparent 68%);',
        'transform:translate(-50%,-50%);animation:orbBreath 7.5s ease-in-out infinite;}',
      '.orb__ball{width:calc(98px*var(--u));height:calc(98px*var(--u));border-radius:50%;transform:translate(-50%,-50%);',
        'background:radial-gradient(circle at 33% 27%,#fff7e6,var(--orb-core-a) 34%,var(--orb-core-b) 66%,#c8541b 100%);',
        'box-shadow:0 0 calc(64px*var(--u)) rgba(255,148,60,.55),inset 0 0 calc(26px*var(--u)) rgba(255,255,255,.35);',
        'overflow:hidden;}',
      '.orb__swirl{position:absolute;inset:0;border-radius:50%;',
        'background:conic-gradient(from 0deg,rgba(255,255,255,0),rgba(255,255,255,.30) 18%,rgba(255,255,255,0) 52%);',
        'animation:orbSwirl 17s linear infinite;}',
      '.orb__halo2{width:calc(158px*var(--u));height:calc(158px*var(--u));border-radius:50%;',
        'border:1px solid rgba(255,206,142,.26);transform:translate(-50%,-50%);',
        'animation:orbRipple 5.5s ease-in-out infinite;}',
      '.orb__corelabel{transform:translate(-50%,calc(64px*var(--u)));white-space:nowrap;',
        'font-size:max(11px,calc(15px*var(--u)));font-weight:500;letter-spacing:.01em;}',

      /* ---- nodes ---- */
      '.orb__node{position:absolute;transform:translate(-50%,-50%);text-align:center;}',
      '.orb__lift{display:block;animation:orbFloat 7s ease-in-out infinite;animation-delay:var(--d,0s);}',
      '.orb__disc{width:calc(var(--s)*1px*var(--u));height:calc(var(--s)*1px*var(--u));border-radius:50%;',
        'display:flex;align-items:center;justify-content:center;margin:0 auto;color:rgb(var(--a));',
        'background:radial-gradient(120% 120% at 30% 24%,rgba(255,255,255,.24),rgba(255,255,255,.06) 46%,rgba(255,255,255,.02));',
        'border:1px solid rgba(255,255,255,.22);',
        'box-shadow:0 0 calc(30px*var(--u)) rgba(var(--a),.40),inset 0 0 calc(22px*var(--u)) rgba(255,255,255,.10);',
        '-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);}',
      '.orb__disc svg{width:52%;height:52%;fill:none;stroke:currentColor;stroke-width:1.6;',
        'stroke-linecap:round;stroke-linejoin:round;}',
      '.orb__name{display:block;margin-top:calc(10px*var(--u));white-space:nowrap;',
        'font-size:max(10px,calc(14px*var(--u)));letter-spacing:.005em;}',

      /* ---- waypoints ---- */
      '.orb__dot{position:absolute;transform:translate(-50%,-50%);border-radius:50%;background:rgb(var(--a));',
        'box-shadow:0 0 calc(14px*var(--u)) rgba(var(--a),.85);animation:orbBlink 4.5s ease-in-out infinite;',
        'animation-delay:var(--d,0s);}',

      /* ---- annotation tags ---- */
      '.orb__tag{position:absolute;font-size:max(9px,calc(11.5px*var(--u)));line-height:1.4;',
        'color:var(--orb-muted);max-width:calc(160px*var(--u));}',
      '.orb__tag--right{transform:translateY(-50%);text-align:left;}',
      '.orb__tag--left{transform:translate(-100%,-50%);text-align:right;}',
      '.orb__tag i{display:block;height:1px;margin-top:calc(6px*var(--u));width:calc(52px*var(--u));}',
      '.orb__tag--right i{background:linear-gradient(90deg,rgba(200,216,255,.55),transparent);}',
      '.orb__tag--left i{margin-left:auto;background:linear-gradient(270deg,rgba(200,216,255,.55),transparent);}',

      /* ---- sparkles ---- */
      '.orb__spark{position:absolute;transform:translate(-50%,-50%);opacity:.75;',
        'animation:orbTwinkle 4.2s ease-in-out infinite;animation-delay:var(--d,0s);}',
      '.orb__spark svg{display:block;width:100%;height:100%;fill:rgba(255,255,255,.9);',
        'filter:drop-shadow(0 0 6px rgba(190,215,255,.8));}',

      /* ---- keyframes ---- */
      '@keyframes orbTurn{to{transform:rotate(360deg)}}',
      '@keyframes orbFlow{to{stroke-dashoffset:-216}}',
      '@keyframes orbSwirl{to{transform:rotate(360deg)}}',
      '@keyframes orbFloat{0%,100%{transform:translateY(calc(-6px*var(--u)))}50%{transform:translateY(calc(6px*var(--u)))}}',
      '@keyframes orbBreath{0%,100%{transform:translate(-50%,-50%) scale(1);opacity:.85}50%{transform:translate(-50%,-50%) scale(1.07);opacity:1}}',
      '@keyframes orbRipple{0%,100%{transform:translate(-50%,-50%) scale(1);opacity:.5}50%{transform:translate(-50%,-50%) scale(1.13);opacity:.16}}',
      '@keyframes orbBlink{0%,100%{opacity:.45}50%{opacity:1}}',
      '@keyframes orbTwinkle{0%,100%{opacity:.35;transform:translate(-50%,-50%) scale(.86)}50%{opacity:1;transform:translate(-50%,-50%) scale(1)}}',

      /* ---- guards ---- */
      '.orb.is-paused *,.orb.is-paused{animation-play-state:paused!important;}',
      '@media (prefers-reduced-motion:reduce){.orb *{animation:none!important}}',
      '@media (max-width:640px){.orb__tag{display:none}}'
    ].join('');
  }

  function injectStyle() {
    if (document.getElementById('orb-style')) return;
    var st = document.createElement('style');
    st.id = 'orb-style';
    st.textContent = styleText();
    document.head.appendChild(st);
  }

  /* ------------------------------------------------------------- helpers */
  function svg(tag, attrs) {
    var n = document.createElementNS(SVGNS, tag);
    for (var k in attrs) if (attrs[k] != null) n.setAttribute(k, attrs[k]);
    return n;
  }
  function el(tag, cls, css) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (css) n.style.cssText = css;
    return n;
  }
  function px(v, total) { return (v / total * 100).toFixed(4) + '%'; }
  function place(node, x, y) { node.style.left = px(x, VW); node.style.top = px(y, VH); }

  // Ellipse as a path so <animateMotion> can ride it.
  function ellipsePath(cx, cy, rx, ry) {
    return 'M' + (cx - rx) + ' ' + cy +
           ' a' + rx + ' ' + ry + ' 0 1 0 ' + (rx * 2) + ' 0' +
           ' a' + rx + ' ' + ry + ' 0 1 0 ' + (-rx * 2) + ' 0';
  }

  // Quadratic curve between two points, bowed sideways by `bend`.
  function curvePath(a, b, bend) {
    var mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    var dx = b.x - a.x, dy = b.y - a.y;
    var len = Math.sqrt(dx * dx + dy * dy) || 1;
    return 'M' + a.x + ' ' + a.y +
           ' Q' + (mx - dy / len * bend).toFixed(1) + ' ' + (my + dx / len * bend).toFixed(1) +
           ' ' + b.x + ' ' + b.y;
  }

  function iconSvg(name) {
    return '<svg viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || ICONS.pulse) + '</svg>';
  }

  /* --------------------------------------------------------------- render */
  function render(root, cfg) {
    cfg = cfg || CONFIG;
    injectStyle();
    root.innerHTML = '';
    root.classList.add('orb');
    var seed = ++uid;

    /* --- points lookup (core + nodes) for the connectors --- */
    var points = { core: cfg.core };
    cfg.nodes.forEach(function (n) { points[n.id] = n; });

    /* --- SVG layer: connectors first, then orbits on top --- */
    var s = svg('svg', {
      'class': 'orb__svg', viewBox: '0 0 ' + VW + ' ' + VH,
      preserveAspectRatio: 'xMidYMid meet', 'aria-hidden': 'true', focusable: 'false'
    });

    (cfg.links || []).forEach(function (l) {
      var a = points[l.from], b = points[l.to];
      if (!a || !b) return;
      s.appendChild(svg('path', { 'class': 'orb__link', d: curvePath(a, b, l.bend || 0) }));
    });

    (cfg.rings || []).forEach(function (r, i) {
      var pid = 'orbPath' + seed + '-' + i;
      var g = svg('g', { 'class': 'orb__spin' });
      g.style.setProperty('--dur', (r.dur || 180) + 's');
      g.style.setProperty('--dir', r.dir === -1 ? 'reverse' : 'normal');
      // Base tilt is baked into the path group so the CSS spin stays a pure rotate.
      var tilt = svg('g', { transform: 'rotate(' + (r.rot || 0) + ' ' + cfg.core.x + ' ' + cfg.core.y + ')' });

      var p = svg('path', {
        id: pid,
        'class': 'orb__ring' + (r.flow ? ' orb__ring--flow' : ''),
        d: ellipsePath(cfg.core.x, cfg.core.y, r.rx, r.ry)
      });
      tilt.appendChild(p);

      if (r.travel) {
        var dot = svg('circle', { 'class': 'orb__travel', r: 2.6, cx: 0, cy: 0 });
        var mo = svg('animateMotion', { dur: r.travel + 's', repeatCount: 'indefinite', rotate: 'auto' });
        var mp = svg('mpath', {});
        mp.setAttribute('href', '#' + pid);
        mp.setAttributeNS(XLINK, 'xlink:href', '#' + pid);   // old WebKit
        mo.appendChild(mp);
        dot.appendChild(mo);
        tilt.appendChild(dot);
      }
      g.appendChild(tilt);
      s.appendChild(g);
    });
    root.appendChild(s);

    /* --- core --- */
    var core = el('div', 'orb__core');
    place(core, cfg.core.x, cfg.core.y);
    core.appendChild(el('span', 'orb__halo'));
    var ball = el('span', 'orb__ball');
    ball.appendChild(el('span', 'orb__swirl'));
    core.appendChild(ball);
    core.appendChild(el('span', 'orb__halo2'));
    var clabel = el('span', 'orb__corelabel');
    clabel.textContent = cfg.core.label || '';
    core.appendChild(clabel);
    root.appendChild(core);

    /* --- nodes --- */
    (cfg.nodes || []).forEach(function (n, i) {
      var wrap = el('div', 'orb__node');
      place(wrap, n.x, n.y);
      var lift = el('span', 'orb__lift');
      lift.style.setProperty('--d', (i * 0.9).toFixed(2) + 's');
      var disc = el('span', 'orb__disc');
      disc.style.setProperty('--s', n.size || 62);
      disc.style.setProperty('--a', n.accent || '255,255,255');
      disc.innerHTML = iconSvg(n.icon);
      var name = el('span', 'orb__name');
      name.textContent = n.label || '';
      lift.appendChild(disc);
      lift.appendChild(name);
      wrap.appendChild(lift);
      root.appendChild(wrap);
    });

    /* --- waypoints --- */
    (cfg.dots || []).forEach(function (d, i) {
      var n = el('span', 'orb__dot');
      place(n, d.x, d.y);
      n.style.width = n.style.height = 'calc(' + (d.r || 6) + 'px*var(--u)*2)';
      n.style.setProperty('--a', d.accent || '255,255,255');
      n.style.setProperty('--d', (i * 0.7).toFixed(2) + 's');
      root.appendChild(n);
    });

    /* --- tags --- */
    (cfg.tags || []).forEach(function (t) {
      var n = el('div', 'orb__tag orb__tag--' + (t.side === 'left' ? 'left' : 'right'));
      place(n, t.x, t.y);
      n.appendChild(document.createTextNode(t.text));
      n.appendChild(el('i'));
      root.appendChild(n);
    });

    /* --- sparkles --- */
    var STAR = '<svg viewBox="0 0 24 24"><path d="M12 0c.7 7.6 3.7 10.9 12 12-8.3 1.1-11.3 4.4-12 12-.7-7.6-3.7-10.9-12-12C8.3 10.9 11.3 7.6 12 0Z"/></svg>';
    (cfg.sparkles || []).forEach(function (sp, i) {
      var n = el('span', 'orb__spark');
      place(n, sp.x, sp.y);
      n.style.width = n.style.height = 'calc(' + (sp.s || 14) + 'px*var(--u))';
      n.style.setProperty('--d', (i * 0.55).toFixed(2) + 's');
      n.innerHTML = STAR;
      root.appendChild(n);
    });

    return s;
  }

  /* --------------------------------------------------------------- attach */
  function attach(root) {
    var s = render(root, root.__orbCfg || CONFIG);

    function unit() {
      var w = root.getBoundingClientRect().width;
      if (w) root.style.setProperty('--u', (w / VW).toFixed(4));
    }
    function play() { root.classList.remove('is-paused'); if (s.unpauseAnimations) s.unpauseAnimations(); }
    function pause() { root.classList.add('is-paused'); if (s.pauseAnimations) s.pauseAnimations(); }

    if ('ResizeObserver' in window) new ResizeObserver(unit).observe(root);
    else window.addEventListener('resize', unit);
    unit();

    if (REDUCED) { pause(); return; }

    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (e) {
        (e[0].isIntersecting && !document.hidden) ? play() : pause();
      }, { threshold: 0.05 }).observe(root);
    }
    document.addEventListener('visibilitychange', function () {
      document.hidden ? pause() : play();
    });
  }

  function init() {
    var list = document.querySelectorAll('[data-orbit]');
    for (var i = 0; i < list.length; i++) attach(list[i]);
  }

  window.OrbitMastery = {
    config: CONFIG,
    icons: ICONS,
    render: render,
    mount: function (elm, cfg) { elm.__orbCfg = cfg || CONFIG; attach(elm); }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
